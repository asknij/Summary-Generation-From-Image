package com.example.flaskserver;

import androidx.appcompat.app.AppCompatActivity;
import cz.msebera.android.httpclient.Header;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

public class ExampleFlask extends AppCompatActivity implements View.OnClickListener {
    Button btnsubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_flask);

        btnsubmit=findViewById(R.id.btnsubmit);
        btnsubmit.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("message", "feedback");

        //Toast.makeText(Selectetype.this, "dsefdg", Toast.LENGTH_SHORT).show();
        client.post("http://192.168.43.212:5000", params, new TextHttpResponseHandler() {


            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                Toast.makeText(ExampleFlask.this, "Failed"+statusCode, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                Toast.makeText(ExampleFlask.this, "Success"+responseString, Toast.LENGTH_SHORT).show();
            }
        });
        }
}
