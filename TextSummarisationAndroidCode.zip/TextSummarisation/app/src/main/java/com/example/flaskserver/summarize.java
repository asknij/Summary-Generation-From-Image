package com.example.flaskserver;

import androidx.appcompat.app.AppCompatActivity;
import cz.msebera.android.httpclient.Header;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

public class summarize extends AppCompatActivity implements View.OnClickListener{

    EditText res;
    Button read;
    String result;
    String sumary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summarize);
        res=findViewById(R.id.res);
        read=findViewById(R.id.read);
        read.setOnClickListener(this);
        Intent intent = getIntent();
        sumary=intent.getStringExtra("summary");
        res.setText(sumary);
    }

    @Override
    public void onClick(View view) {

        result=res.getText().toString();


            Intent i= new Intent(summarize.this,speechtext.class);
        i.putExtra("result",result);
        startActivity(i);

    }
}
