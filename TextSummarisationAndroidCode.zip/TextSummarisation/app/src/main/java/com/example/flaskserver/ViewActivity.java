package com.example.flaskserver;

import androidx.appcompat.app.AppCompatActivity;
import cz.msebera.android.httpclient.Header;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ViewActivity extends AppCompatActivity implements View.OnClickListener{

    EditText txtresult;
    Button sumi;
    String txt;
    String s;
    String res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        Intent intent = getIntent();
        txt=intent.getStringExtra("text");
        txtresult=findViewById(R.id.result);
        sumi=findViewById(R.id.Summarize);
        txtresult.setText(txt);

        sumi.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        s=txtresult.getText().toString();
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("message", s);

        //Toast.makeText(Selectetype.this, "dsefdg", Toast.LENGTH_SHORT).show();
        client.post("https://nltktextsummarizer.herokuapp.com/summarize", params, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                Toast.makeText(ViewActivity.this, "Failed"+statusCode, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {

                Toast.makeText(ViewActivity.this, "Success"+responseString, Toast.LENGTH_SHORT).show();
                res = responseString.toString().trim();


//
//                try {
//                    JSONArray ja = new JSONArray(responseString);
//
//
//                    JSONObject job = ja.getJSONObject(0);
//                    res= job.getString("summary");
//                    Toast.makeText(ViewActivity.this, "res:  "+res, Toast.LENGTH_SHORT).show();
//                    Log.d("res",res);
//
//                }catch (JSONException e) {
//                    e.printStackTrace();
//                }

                        Intent i=new Intent(ViewActivity.this,summarize.class);
                        i.putExtra("summary",responseString);
                        startActivity(i);

            }

        });


    }
}
